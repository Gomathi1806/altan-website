import React, { useState } from 'react'
import SpeechRecognition, {
  useSpeechRecognition
} from 'react-speech-recognition'
import { useSpeechSynthesis } from 'react-speech-kit'
import './App.css' // Import the CSS file

const App = () => {
  const [waitingList, setWaitingList] = useState([])
  const [message, setMessage] = useState('')

  const { transcript, resetTranscript } = useSpeechRecognition()
  const { speak } = useSpeechSynthesis()

  const handleJoinWaitingList = () => {
    setWaitingList([...waitingList, message])
    setMessage('')
    resetTranscript()
  }

  const handleVoiceInput = () => {
    SpeechRecognition.startListening({ continuous: true })
  }

  const handleTextToSpeech = () => {
    speak({ text: message })
  }

  return (
    <div className='App' style='Backgroundimage'>
      Hello World
      {/* Header */}
      <header>
        <nav>
          <ul>
            <li>Home</li>
            <li>All About AiNGEL</li>
            <li>Knowledge</li>
            <li>Research</li>
            <li>Contact</li>
            <li>
              <button>Sign In</button>
            </li>
            <li>
              <button>Sign Up</button>
            </li>
          </ul>
        </nav>
      </header>
      {/* Main Content */}
      <main>
        <h1>AiNGEL: Your Voice First Virtual Companion for a Healthier Life</h1>
        <div>
          <input
            type='text'
            value={message}
            onChange={e => setMessage(e.target.value)}
            placeholder='Write or Speak To Me...'
          />
          <button onClick={handleVoiceInput}>
            <i className='fa fa-microphone'></i>
          </button>
          <button onClick={handleTextToSpeech}>
            <i className='fa fa-volume-up'></i>
          </button>
        </div>
        <p>{transcript}</p>
        <button onClick={handleJoinWaitingList}>Join the Waiting List</button>
        <ul>
          {waitingList.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
        <img src='elderly-woman.jpg' alt='AiNGEL' />
      </main>
      {/* Footer */}
      <footer>
        <nav>
          <ul>
            <li>Terms and Conditions</li>
            <li>Be A Game-Changer</li>
            <li>Privacy Policy</li>
          </ul>
        </nav>
      </footer>
    </div>
  )
}

export default App
