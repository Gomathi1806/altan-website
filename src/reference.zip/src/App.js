// App.js
import React from 'react'
import './App.css' // Import the CSS file

function App () {
  return <div className='background-image'>Hello World</div>
}

export default App
