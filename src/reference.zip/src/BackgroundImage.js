import React from 'react'
import backgroundImage from './images/aingel.png'

const BackgroundImage = () => {
  return (
    <div
      className='background-image'
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className='text-container'>
        <h1>Your Text Here</h1>
      </div>
    </div>
  )
}

export default BackgroundImage
